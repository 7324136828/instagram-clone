Holiday pictures. There is no post.json in this archive.
